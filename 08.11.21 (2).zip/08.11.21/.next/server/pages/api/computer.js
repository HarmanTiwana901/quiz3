"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/computer";
exports.ids = ["pages/api/computer"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "./src/pages/api/computer.ts":
/*!***********************************!*\
  !*** ./src/pages/api/computer.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nconst prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\nasync function handler(req, res) {\n    if (req.method === 'POST') {\n        if (req.body.searchInput) {\n            const computer = await prisma.computer.findMany({\n                where: {\n                    brand: req.body.searchInput\n                }\n            });\n            res.status(200).json(computer);\n            console.log('Data Read:');\n            console.log(computer);\n        } else {\n            const computer = await prisma.computer.create({\n                data: {\n                    brand: req.body.brand,\n                    model: req.body.model,\n                    price: req.body.price\n                }\n            });\n            res.status(200).json(computer);\n            console.log('Data Sent: ');\n        }\n    } else if (req.method === 'GET') {\n        const computer = await prisma.computer.findMany({\n            select: {\n                brand: true,\n                model: true,\n                price: true,\n                id: true\n            }\n        });\n        res.status(200).json(computer);\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvYXBpL2NvbXB1dGVyLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUU2QztBQUM3QyxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNELHdEQUFZO0FBZWhCLGVBQWVFLE9BQU8sQ0FBQ0MsR0FBbUIsRUFBRUMsR0FBeUMsRUFBRSxDQUFDO0lBR3JHLEVBQUUsRUFBQ0QsR0FBRyxDQUFDRSxNQUFNLEtBQUssQ0FBTSxPQUFFLENBQUM7UUFFekIsRUFBRSxFQUFDRixHQUFHLENBQUNHLElBQUksQ0FBQ0MsV0FBVyxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDQyxRQUFRLEdBQUcsS0FBSyxDQUFDUCxNQUFNLENBQUNPLFFBQVEsQ0FBQ0MsUUFBUSxDQUM3QyxDQUFDO2dCQUNDQyxLQUFLLEVBQUUsQ0FBQztvQkFDTkMsS0FBSyxFQUFFUixHQUFHLENBQUNHLElBQUksQ0FBQ0MsV0FBVztnQkFDN0IsQ0FBQztZQUNILENBQUM7WUFFSEgsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7WUFDN0JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQVk7WUFDeEJELE9BQU8sQ0FBQ0MsR0FBRyxDQUFDUCxRQUFRO1FBQ3RCLENBQUMsTUFBTSxDQUFDO1lBQ04sS0FBSyxDQUFDQSxRQUFRLEdBQUcsS0FBSyxDQUFDUCxNQUFNLENBQUNPLFFBQVEsQ0FBQ1EsTUFBTSxDQUMzQyxDQUFDO2dCQUNDQyxJQUFJLEVBQUUsQ0FBQztvQkFDTE4sS0FBSyxFQUFFUixHQUFHLENBQUNHLElBQUksQ0FBQ0ssS0FBSztvQkFDckJPLEtBQUssRUFBRWYsR0FBRyxDQUFDRyxJQUFJLENBQUNZLEtBQUs7b0JBQ3JCQyxLQUFLLEVBQUVoQixHQUFHLENBQUNHLElBQUksQ0FBQ2EsS0FBSztnQkFDdkIsQ0FBQztZQUNILENBQUM7WUFFSGYsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7WUFDN0JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWE7UUFDM0IsQ0FBQztJQUNILENBQUMsTUFBTSxFQUFFLEVBQUNaLEdBQUcsQ0FBQ0UsTUFBTSxLQUFLLENBQUssTUFBRSxDQUFDO1FBQy9CLEtBQUssQ0FBQ0csUUFBUSxHQUFHLEtBQUssQ0FBQ1AsTUFBTSxDQUFDTyxRQUFRLENBQUNDLFFBQVEsQ0FDN0MsQ0FBQztZQUNDVyxNQUFNLEVBQUUsQ0FBQztnQkFDUFQsS0FBSyxFQUFFLElBQUk7Z0JBQ1hPLEtBQUssRUFBRSxJQUFJO2dCQUNYQyxLQUFLLEVBQUUsSUFBSTtnQkFDWEUsRUFBRSxFQUFFLElBQUk7WUFDVixDQUFDO1FBQ0gsQ0FBQztRQUVIakIsR0FBRyxDQUFDUSxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUNMLFFBQVE7SUFHL0IsQ0FBQztBQU1ELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8wOC4xMS4yMS8uL3NyYy9wYWdlcy9hcGkvY29tcHV0ZXIudHM/ZGJhNCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBOZXh0LmpzIEFQSSByb3V0ZSBzdXBwb3J0OiBodHRwczovL25leHRqcy5vcmcvZG9jcy9hcGktcm91dGVzL2ludHJvZHVjdGlvblxyXG5pbXBvcnQgdHlwZSB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tICdAcHJpc21hL2NsaWVudCdcclxuY29uc3QgcHJpc21hID0gbmV3IFByaXNtYUNsaWVudCgpO1xyXG50eXBlIENvbXB1dGVyID0ge1xyXG4gXHJcbiAgYnJhbmQ6IHN0cmluZztcclxuICBtb2RlbDogc3RyaW5nO1xyXG4gIHByaWNlOiBudW1iZXI7XHJcbn1cclxuXHJcbnR5cGUgQm9keSA9IHtcclxuICBcclxuICBicmFuZDogc3RyaW5nO1xyXG4gIG1vZGVsOiBzdHJpbmc7XHJcbiAgcHJpY2U6IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXE6IE5leHRBcGlSZXF1ZXN0LCByZXM6IE5leHRBcGlSZXNwb25zZTxDb21wdXRlcnxDb21wdXRlcltdPikge1xyXG5cclxuICBcclxuICBpZihyZXEubWV0aG9kID09PSAnUE9TVCcpIHtcclxuXHJcbiAgICBpZihyZXEuYm9keS5zZWFyY2hJbnB1dCkge1xyXG4gICAgICBjb25zdCBjb21wdXRlciA9IGF3YWl0IHByaXNtYS5jb21wdXRlci5maW5kTWFueShcclxuICAgICAgICB7XHJcbiAgICAgICAgICB3aGVyZToge1xyXG4gICAgICAgICAgICBicmFuZDogcmVxLmJvZHkuc2VhcmNoSW5wdXRcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oY29tcHV0ZXIpO1xyXG4gICAgICBjb25zb2xlLmxvZygnRGF0YSBSZWFkOicpO1xyXG4gICAgICBjb25zb2xlLmxvZyhjb21wdXRlcik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBjb21wdXRlciA9IGF3YWl0IHByaXNtYS5jb21wdXRlci5jcmVhdGUoXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZGF0YTogeyAgICAgXHJcbiAgICAgICAgICAgIGJyYW5kOiByZXEuYm9keS5icmFuZCxcclxuICAgICAgICAgICAgbW9kZWw6IHJlcS5ib2R5Lm1vZGVsLFxyXG4gICAgICAgICAgICBwcmljZTogcmVxLmJvZHkucHJpY2VcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oY29tcHV0ZXIpO1xyXG4gICAgICBjb25zb2xlLmxvZygnRGF0YSBTZW50OiAnKVxyXG4gICAgfVxyXG4gIH0gZWxzZSBpZihyZXEubWV0aG9kID09PSAnR0VUJykge1xyXG4gICAgY29uc3QgY29tcHV0ZXIgPSBhd2FpdCBwcmlzbWEuY29tcHV0ZXIuZmluZE1hbnkoXHJcbiAgICAgIHtcclxuICAgICAgICBzZWxlY3Q6IHtcclxuICAgICAgICAgIGJyYW5kOiB0cnVlLFxyXG4gICAgICAgICAgbW9kZWw6IHRydWUsXHJcbiAgICAgICAgICBwcmljZTogdHJ1ZSxcclxuICAgICAgICAgIGlkOiB0cnVlXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICByZXMuc3RhdHVzKDIwMCkuanNvbihjb21wdXRlcik7XHJcbiAgICBcclxuICAgIFxyXG4gIH1cclxuICAgXHJcbiAgICBcclxuICAgIFxyXG5cclxuICAgIFxyXG4gIH1cclxuICAiXSwibmFtZXMiOlsiUHJpc21hQ2xpZW50IiwicHJpc21hIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsImJvZHkiLCJzZWFyY2hJbnB1dCIsImNvbXB1dGVyIiwiZmluZE1hbnkiLCJ3aGVyZSIsImJyYW5kIiwic3RhdHVzIiwianNvbiIsImNvbnNvbGUiLCJsb2ciLCJjcmVhdGUiLCJkYXRhIiwibW9kZWwiLCJwcmljZSIsInNlbGVjdCIsImlkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/api/computer.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/api/computer.ts"));
module.exports = __webpack_exports__;

})();