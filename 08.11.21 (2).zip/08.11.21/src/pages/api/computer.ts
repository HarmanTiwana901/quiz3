// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient();
type Computer = {
 
  brand: string;
  model: string;
  price: number;
}

type Body = {
  
  brand: string;
  model: string;
  price: number;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse<Computer|Computer[]>) {

  
  if(req.method === 'POST') {

    if(req.body.searchInput) {
      const computer = await prisma.computer.findMany(
        {
          where: {
            brand: req.body.searchInput
          }
        }
      )
      res.status(200).json(computer);
      console.log('Data Read:');
      console.log(computer);
    } else {
      const computer = await prisma.computer.create(
        {
          data: {     
            brand: req.body.brand,
            model: req.body.model,
            price: req.body.price
          }
        }
      )
      res.status(200).json(computer);
      console.log('Data Sent: ')
    }
  } else if(req.method === 'GET') {
    const computer = await prisma.computer.findMany(
      {
        select: {
          brand: true,
          model: true,
          price: true,
          id: true
        }
      }
    )
    res.status(200).json(computer);
    
    
  }
   
    
    

    
  }
  