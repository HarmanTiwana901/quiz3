import prisma from '../../../backend/database/client'
export const resolvers = {
    Query: {
        //defining the query
        getComputers: async(objects, args, contect, info) => {
            //args contains ther perameters sent from the suer 
            console.log('args: ', args);

            return prisma.Computer.findMany({
                select: {
                    id: true, 
                    price: true, 
                    model: true,
                    brand: true
                }
            })
        }
    }
}