import {gql} from 'apollo-server-micro';
export const typeDefs = gql`
    type Computer {
        id: ID
        price: String
        model: String
        brand: String
    }

    type Query {
        getComputers: [Computer]
    }
`;