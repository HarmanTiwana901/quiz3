import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'
import {gql} from '@apollo/client';
import client from '../../apollo-client';
import { stringify } from 'querystring';
import {ApolloClient, InMemoryCache} from '@apollo/client'
import prisma from '../backend/database/client'
import { useState } from 'react';
import { InferGetStaticPropsType } from 'next'


function Display({computers}: InferGetStaticPropsType<typeof getStaticProps>) {
  
    const [input, setInput] = useState('');
    var dataStorage = computers;
  
    const fetchData = () => {
      dataStorage = [];
        const options = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({searchInput: input})
          };
          
          const response = fetch('http://localhost:3000/api/computer', options)
          .then(response => response.json()
          .then(data => dataStorage.push(JSON.stringify(data[0]))));
          
          
    }
    
    
  return (


    <div className={styles.container}>
        <h1>Search A Computer</h1>
        <input onChange={(e) => setInput(e.target.value)} type="text" name="search" placeholder="search"></input>
        <button onClick={fetchData} type="button">Search</button>

        
          {dataStorage.map((comp) => (
            <div className={styles.grid}>
              <ul>
                <li key={comp.id}>Brand: {comp.brand}</li><br/>
                <li key={comp.id}>Price: {comp.price}$</li><br/>
                <li key={comp.id}>Model:  {comp.model}</li><br/>
              </ul>
            </div>
          ))}
        
        
    </div>
  )
}


export async function getStaticProps(){
    const options = {
        method: 'GET',
        headers: {'Content-Type': 'application/json'}
      };
    const data = await fetch('http://localhost:3000/api/computer', options);
    const computers = await data.json();

    
  return {
    props: {
        computers
    }
  }
}
export default Display;
